import {v1} from 'uuid';
import {taskReducer} from './reducer';
import {addTask, updateTaskSuccess, deleteTask} from './reducer';
import {addTodoListSuccess, deleteTodoList, setTodos} from '../TodoList/todos';
import {StateType} from './reducer';
import {taskPriority, taskStatus} from '../../api/api';

let id1: string
let id2: string
let newId: string
let idTask: string

let startState: StateType

beforeEach(() => {
   id1 = v1();
   id2 = v1();
   newId = v1();

   idTask = v1();

   startState = {
        [id1]:[
            {
                id: idTask,  
                todoListId: id1,
                title: "HTML&CSS",
                status: taskStatus.New,
                deadline: '',
                description: '',
                priority: taskPriority.Low,
                startDate: '',
                addedDate: '20.05',
                order: 1
            },
            {
                id: v1(), 
                title: "JS", 
                todoListId: id1,
                status: taskStatus.New,
                deadline: '',
                description: '',
                priority: taskPriority.Low,
                startDate: '',
                addedDate: '20.05',
                order: 2
            }
        ],
        [id2]:[
            {
                id: v1(), 
                title: "Ryzen 7 5800X", 
                todoListId: id2,
                status: taskStatus.New,
                deadline: '',
                description: '',
                priority: taskPriority.Low,
                startDate: '',
                addedDate: '20.05',
                order: 2
            },
            {
                id: v1(), 
                title: "MSI GTX 3060", 
                todoListId: id2,
                status: taskStatus.New,
                deadline: '',
                description: '',
                priority: taskPriority.Low,
                startDate: '',
                addedDate: '20.05',
                order: 2
            }
        ]
    }
})

// ADD
test('Correct task should be added', () => { 
    const newTask = {
        id: v1(), 
        title: "TS", 
        todoListId: id1,
        status: taskStatus.New,
        deadline: '',
        description: '',
        priority: taskPriority.Low,
        startDate: '',
        addedDate: '',
        order: 3
    }
    const endState = taskReducer(startState, addTask.fulfilled({todoListId: id1, taskId: idTask}, '', {todoListId: id1, taskId: idTask}))
    expect(endState[id1].length).toBe(3)
    expect(endState[id2].length).toBe(2)
})

// DELETE
test('Correct task should be deleted', () => {
   const endState = taskReducer(startState, deleteTask.fulfilled({todoListId: id1, taskId: idTask}, '', {todoListId: id1, taskId: idTask}))
   expect(endState[id1].every(t => t.id !== idTask)).toBeTruthy();
   expect(endState[id1].length).toBe(1)
   expect(endState[id2].length).toBe(2)
})

// Status change
test('Correct task status changed', () => { 
    const endState = taskReducer(startState, updateTaskSuccess({todoListId: id1, taskId: idTask, model: {status: taskStatus.Completed}})) 
    expect(endState[id1].find(item => item.id === idTask)?.status).toBe(taskStatus.Completed)
})

// Title update
test('Correct task title updated', () => { 
    const endState = taskReducer(startState, updateTaskSuccess({todoListId: id1, taskId: idTask, model: {title: 'New task title'}})) 
    expect(endState[id1].find(item => item.id === idTask)?.title).toBe('New task title')
})

// Add new array in task array
test('New array should be added when new todoList is added', () => { 
    const endState = taskReducer(startState, addTodoListSuccess({title: 'New title', id: newId}));
    const keys = Object.keys(endState);

    const newKey = keys.find(key => key !== id1 && key !== id2)
    if(!newKey) {
       throw Error('Error')
    }
    expect(keys.length).toBe(3)
    expect(endState[newKey]).toEqual([])
})

 // Delete array in task array
 test('Task array should be deleted when todoList is deleted', () => { 
    const endState = taskReducer(startState, deleteTodoList({id: id2}));
    const keys = Object.keys(endState);

    expect(keys.length).toBe(1)
    expect(endState[id2]).toBeUndefined()
})

 // Delete array in task array
 test('Empty arrays should be added when we set todos', () => { 

    const action = setTodos({data: [
        {
            id: '1', 
            title: "What to learn"
        },
        {
            id: '2', 
            title: "What to buy"
        }
    ]})

    const endState = taskReducer({}, action)
    const keys = Object.keys(endState);

    expect(keys.length).toBe(2)
    expect(endState['1']).toBeDefined()
    expect(endState['2']).toBeDefined()
})