import {v1} from 'uuid';
import {todoReducer}, {toggleTodoStatus} from './todos';
import {deleteTodoList, addTodoList, changeTodoListTitle, changeTodoListFilter, setTodos} from './todos';
import {todoListType} from './todos';

let id1: string
let id2: string
let newId: string
let title: string

let startState: todoListType[];

beforeEach(() => {
    id1 = v1();
    id2 = v1();
    newId = v1();
    title = 'New title';

    startState = [
        {
            id: id1, 
            title: "What to learn", 
            filter: "ALL",
            status: 'idle'
        },
        {
            id: id2, 
            title: "What to buy", 
            filter: "ALL",
            status: 'idle'
        }
    ]
})

test('Correct todolist should be deleted', () => {
   const endState = todoReducer(startState, deleteTodoList({id: id1}))
   expect(endState.length).toBe(1);
   expect(endState[0].id).toBe(id2);
})

test('Correct todolist should be added', () => { 
    const endState = todoReducer(startState, addTodoListAC(title, newId))
    expect(endState.length).toBe(3);
    expect(endState[2].title).toBe(title);
    expect(endState[2].id).toBe(newId);
})

test('todoList title should be changed', () => { 
    const endState = todoReducer(startState, changeTodoListTitleAC(id1, title))
    expect(endState.length).toBe(2);
    expect(endState[0].title).toBe(title);
})

test('todoList filter should be changed', () => { 
    const endState = todoReducer(startState, changeTodoListFilterAC(id1, 'ALL'))
    expect(endState.length).toBe(2);
    expect(endState[0].filter).toBe('ALL');
})

test('todoLists should be set to State', () => { 
    const endState = todoReducer([], setTodosAC(startState))
    expect(endState.length).toBe(2);
})

test('todoLists status should be change', () => { 
    const endState = todoReducer(startState, toggleTodoStatusAC(id1, 'loading'))
    expect(endState[0].status).toBe('loading');
})